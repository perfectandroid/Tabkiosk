package com.maniparambil.jijo.tabkiosk.Activity;

import android.os.Bundle;

import com.maniparambil.tabkiosk2.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_reason);
    }
}
