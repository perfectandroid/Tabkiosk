package com.maniparambil.jijo.tabkiosk.Activity;

import android.os.Bundle;

import com.maniparambil.tabkiosk2.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity_Thankyou extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_thankyou_complaint);
    }
}
